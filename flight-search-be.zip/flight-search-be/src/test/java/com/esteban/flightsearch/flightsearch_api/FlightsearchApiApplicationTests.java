package com.esteban.flightsearch.flightsearch_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightsearchApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
