package com.esteban.flightsearch.flightsearch_api.model;

public class AirlineLookupResponse {
}
